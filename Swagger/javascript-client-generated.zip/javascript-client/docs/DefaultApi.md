# DjsChain.DefaultApi

All URIs are relative to *http://djs-chain.heroku.com/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**personsGet**](DefaultApi.md#personsGet) | **GET** /Persons | 
[**personsIdDelete**](DefaultApi.md#personsIdDelete) | **DELETE** /Persons/{id} | 
[**personsIdFieldGet**](DefaultApi.md#personsIdFieldGet) | **GET** /Persons/{id}/{field} | 
[**personsIdFieldPut**](DefaultApi.md#personsIdFieldPut) | **PUT** /Persons/{id}/{field} | 
[**personsIdGet**](DefaultApi.md#personsIdGet) | **GET** /Persons/{id} | 
[**personsIdPut**](DefaultApi.md#personsIdPut) | **PUT** /Persons/{id} | 
[**personsPost**](DefaultApi.md#personsPost) | **POST** /Persons | 


<a name="personsGet"></a>
# **personsGet**
> [InlineResponse200] personsGet()



Return all known persons

### Example
```javascript
var DjsChain = require('djs_chain');

var apiInstance = new DjsChain.DefaultApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.personsGet(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**[InlineResponse200]**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="personsIdDelete"></a>
# **personsIdDelete**
> personsIdDelete(id)



Delete a person

### Example
```javascript
var DjsChain = require('djs_chain');

var apiInstance = new DjsChain.DefaultApi();

var id = 56; // Number | the identifier of a person


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.personsIdDelete(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| the identifier of a person | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="personsIdFieldGet"></a>
# **personsIdFieldGet**
> personsIdFieldGet(id, field)



Return the {field} property of the person with that id

### Example
```javascript
var DjsChain = require('djs_chain');

var apiInstance = new DjsChain.DefaultApi();

var id = 56; // Number | the identifier of a person

var field = "field_example"; // String | the name of the property (age or nickname)


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.personsIdFieldGet(id, field, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| the identifier of a person | 
 **field** | **String**| the name of the property (age or nickname) | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain

<a name="personsIdFieldPut"></a>
# **personsIdFieldPut**
> InlineResponse200 personsIdFieldPut(id, field)



Set the {field} property of the person with that id

### Example
```javascript
var DjsChain = require('djs_chain');

var apiInstance = new DjsChain.DefaultApi();

var id = 56; // Number | the identifier of a person

var field = "field_example"; // String | the name of the property (age or nickname)


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.personsIdFieldPut(id, field, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| the identifier of a person | 
 **field** | **String**| the name of the property (age or nickname) | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="personsIdGet"></a>
# **personsIdGet**
> InlineResponse200 personsIdGet(id)



Return the person with that id

### Example
```javascript
var DjsChain = require('djs_chain');

var apiInstance = new DjsChain.DefaultApi();

var id = 56; // Number | the identifier of a person


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.personsIdGet(id, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| the identifier of a person | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="personsIdPut"></a>
# **personsIdPut**
> InlineResponse200 personsIdPut(id, body)



Create or replace a person with that identifier

### Example
```javascript
var DjsChain = require('djs_chain');

var apiInstance = new DjsChain.DefaultApi();

var id = 56; // Number | the identifier of a person

var body = new DjsChain.Body(); // Body | the information of a person


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.personsIdPut(id, body, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Number**| the identifier of a person | 
 **body** | [**Body**](Body.md)| the information of a person | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="personsPost"></a>
# **personsPost**
> InlineResponse200 personsPost(opts)



Create a person

### Example
```javascript
var DjsChain = require('djs_chain');

var apiInstance = new DjsChain.DefaultApi();

var opts = { 
  'personCharacteristics': new DjsChain.PersonCharacteristics1() // PersonCharacteristics1 | the age and nickname of a person
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.personsPost(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **personCharacteristics** | [**PersonCharacteristics1**](PersonCharacteristics1.md)| the age and nickname of a person | [optional] 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

