# DjsChain.PersonCharacteristics1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nickname** | **String** |  | 
**age** | **Number** |  | 


