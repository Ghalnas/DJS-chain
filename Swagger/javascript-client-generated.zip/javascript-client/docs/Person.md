# DjsChain.Person

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**nickname** | **String** |  | 
**age** | **Number** |  | 


