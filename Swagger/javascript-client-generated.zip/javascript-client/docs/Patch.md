# DjsChain.Patch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kind** | **String** | the type of the message | [optional] [default to &#39;update&#39;]
**table** | **String** | the name of the table | [optional] [default to &#39;Person&#39;]
**id** | **Number** | the identifier of the person to patch | [optional] 
**field** | **String** | the name of the property to modify | [optional] 
**value** | **String** | the value to set in the property | [optional] 


