# DjsChain.ArrayOfpersons

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


