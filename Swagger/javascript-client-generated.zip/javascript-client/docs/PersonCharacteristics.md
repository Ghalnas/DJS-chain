# DjsChain.PersonCharacteristics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nickname** | **String** |  | 
**age** | **Number** |  | 


