# DjsChain.InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | 
**nickname** | **String** |  | 
**age** | **Number** |  | 


